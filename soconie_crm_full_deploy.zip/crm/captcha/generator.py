"""
Slider Puzzle CAPTCHA Generator for Soconie CRM.
Loads real landscape images, randomly crops, jitters, finds high-contrast edge regions,
and cuts a jigsaw puzzle piece with transparent PNG overlays.
"""
import os
import io
import math
import base64
import random
import secrets
import logging
from typing import Dict, Any, Tuple, Optional
from PIL import Image, ImageDraw, ImageFilter, ImageEnhance

from crm.site_config import CAPTCHA_ASSETS_DIR

logger = logging.getLogger("soconie.captcha")

_last_used_image_path = None


def get_available_images() -> list:
    """Scans CAPTCHA_ASSETS_DIR for image files (.jpg, .jpeg, .png, .webp)."""
    valid_exts = ('.jpg', '.jpeg', '.png', '.webp')
    if not os.path.exists(CAPTCHA_ASSETS_DIR):
        os.makedirs(CAPTCHA_ASSETS_DIR, exist_ok=True)
        return []

    images = []
    for fn in os.listdir(CAPTCHA_ASSETS_DIR):
        if fn.lower().endswith(valid_exts):
            full_path = os.path.join(CAPTCHA_ASSETS_DIR, fn)
            # Try to verify image is not corrupted
            try:
                with Image.open(full_path) as im:
                    im.verify()
                images.append(full_path)
            except Exception as e:
                logger.warning(f"Bỏ qua ảnh CAPTCHA hỏng: {fn} - {e}")

    if len(images) < 8:
        logger.warning(f"Nên thêm ảnh cho CAPTCHA (hiện có {len(images)}/8 ảnh khuyến nghị trong {CAPTCHA_ASSETS_DIR})")

    return images


def select_random_image() -> str:
    """Crypto-safe random image selector, avoiding immediate repeat."""
    global _last_used_image_path
    images = get_available_images()
    if not images:
        raise FileNotFoundError(f"Không tìm thấy ảnh CAPTCHA hợp lệ trong {CAPTCHA_ASSETS_DIR}")

    if len(images) == 1:
        return images[0]

    # Pick candidate not matching last used
    choices = [p for p in images if p != _last_used_image_path]
    if not choices:
        choices = images

    selected = secrets.choice(choices)
    _last_used_image_path = selected
    return selected


def create_jigsaw_mask(size: int = 46, pad: int = 10, tabs: Tuple[int, int, int, int] = (1, 1, 0, -1)) -> Image.Image:
    """
    Creates an alpha mask for a jigsaw puzzle piece.
    tabs: (top, right, bottom, left) where 1=outward tab, -1=inward slot, 0=flat.
    """
    w = size + 2 * pad
    h = size + 2 * pad
    mask = Image.new('L', (w, h), 0)
    draw = ImageDraw.Draw(mask)

    x0, y0 = pad, pad
    x1, y1 = pad + size, pad + size

    # Base square
    draw.rectangle([x0, y0, x1, y1], fill=255)

    r = int(size * 0.22)
    cx = (x0 + x1) // 2
    cy = (y0 + y1) // 2

    # Top tab
    if tabs[0] == 1:
        draw.ellipse([cx - r, y0 - r, cx + r, y0 + r], fill=255)
    elif tabs[0] == -1:
        draw.ellipse([cx - r, y0 - r, cx + r, y0 + r], fill=0)

    # Right tab
    if tabs[1] == 1:
        draw.ellipse([x1 - r, cy - r, x1 + r, cy + r], fill=255)
    elif tabs[1] == -1:
        draw.ellipse([x1 - r, cy - r, x1 + r, cy + r], fill=0)

    # Bottom tab
    if tabs[2] == 1:
        draw.ellipse([cx - r, y1 - r, cx + r, y1 + r], fill=255)
    elif tabs[2] == -1:
        draw.ellipse([cx - r, y1 - r, cx + r, y1 + r], fill=0)

    # Left tab
    if tabs[3] == 1:
        draw.ellipse([x0 - r, cy - r, x0 + r, cy + r], fill=255)
    elif tabs[3] == -1:
        draw.ellipse([x0 - r, cy - r, x0 + r, cy + r], fill=0)

    return mask


def measure_region_contrast(edge_img: Image.Image, x: int, y: int, w: int, h: int) -> float:
    """Computes edge detail / standard deviation score for candidate window."""
    try:
        box = (x, y, x + w, y + h)
        crop = edge_img.crop(box)
        stat = crop.convert('L').histogram()
        total_pixels = w * h
        mean = sum(i * count for i, count in enumerate(stat)) / total_pixels
        variance = sum(((i - mean) ** 2) * count for i, count in enumerate(stat)) / total_pixels
        return variance
    except Exception:
        return 0.0


def generate_puzzle_challenge(width: int = 320, height: int = 160) -> Dict[str, Any]:
    """
    Generates a full slider puzzle CAPTCHA challenge.
    Outputs background image with cutout slot, floating puzzle piece, and metadata.
    """
    img_path = select_random_image()
    filename = os.path.basename(img_path).lower()
    is_captcha_04 = "04" in filename or "good day" in filename

    raw_img = Image.open(img_path).convert('RGB')
    orig_w, orig_h = raw_img.size

    # Random scale 100% - 135%
    scale_factor = random.uniform(1.0, 1.35)
    
    # 2:1 aspect ratio crop
    crop_w = int(orig_w / scale_factor)
    crop_h = crop_w // 2
    if crop_h > orig_h:
        crop_h = orig_h
        crop_w = min(orig_w, crop_h * 2)

    # For captcha-04: Avoid the text "Have a good day" (located in the upper-middle Y 35%-60%)
    if is_captcha_04:
        # Crop from the lower rolling hills region where grass and shadows provide high contrast
        max_y = orig_h - crop_h
        min_y = int(orig_h * 0.45)
        top = random.randint(min(min_y, max_y), max_y) if max_y >= min_y else max_y
    else:
        max_y = max(0, orig_h - crop_h)
        top = random.randint(0, max_y)

    left = max(0, (orig_w - crop_w) // 2)
    cropped = raw_img.crop((left, top, left + crop_w, top + crop_h))

    # Random horizontal flip (50%) - only for non-text images
    if not is_captcha_04 and random.random() > 0.5:
        cropped = cropped.transpose(Image.Transpose.FLIP_LEFT_RIGHT)

    # Random slight rotation ±3°
    angle = random.uniform(-3.0, 3.0)
    cropped = cropped.rotate(angle, resample=Image.Resampling.BICUBIC, expand=False)

    # Jitter brightness & contrast slightly
    b_jitter = random.uniform(0.96, 1.04)
    c_jitter = random.uniform(0.96, 1.04)
    cropped = ImageEnhance.Brightness(cropped).enhance(b_jitter)
    cropped = ImageEnhance.Contrast(cropped).enhance(c_jitter)

    # Resize to exact display dimensions (320x160)
    base_img = cropped.resize((width, height), Image.Resampling.LANCZOS)

    # Prepare edge detection to find high-contrast slot position
    edge_map = base_img.filter(ImageFilter.FIND_EDGES).filter(ImageFilter.SMOOTH_MORE)

    # Puzzle piece size 44-52px
    piece_size = random.randint(44, 50)
    pad = 10
    total_piece_w = piece_size + 2 * pad
    total_piece_h = piece_size + 2 * pad

    # Random puzzle tabs (1, -1, 0)
    possible_tabs = [
        (1, 1, 0, -1),
        (1, -1, 1, 0),
        (0, 1, -1, 1),
        (-1, 1, 1, 0),
        (1, 0, 1, -1)
    ]
    tabs = random.choice(possible_tabs)
    mask = create_jigsaw_mask(piece_size, pad, tabs)

    # Slot search area: 35% to 90% of width
    min_slot_x = int(width * 0.35)
    max_slot_x = int(width * 0.90) - piece_size - pad
    min_slot_y = pad + 4
    max_slot_y = height - piece_size - pad - 6

    # Select best slot with highest edge variance
    best_x = random.randint(min_slot_x, max_slot_x)
    best_y = random.randint(min_slot_y, max_slot_y)
    best_score = -1.0

    for _ in range(12):
        cand_x = random.randint(min_slot_x, max_slot_x)
        cand_y = random.randint(min_slot_y, max_slot_y)
        score = measure_region_contrast(edge_map, cand_x, cand_y, piece_size, piece_size)
        if score > best_score:
            best_score = score
            best_x = cand_x
            best_y = cand_y

    slot_x = best_x
    slot_y = best_y

    # 1. Cut the puzzle piece from base_img
    crop_box = (slot_x - pad, slot_y - pad, slot_x - pad + total_piece_w, slot_y - pad + total_piece_h)
    piece_crop = base_img.crop(crop_box)
    piece_rgba = Image.new('RGBA', (total_piece_w, total_piece_h), (0, 0, 0, 0))
    piece_rgba.paste(piece_crop, (0, 0), mask=mask)

    # Highlight border for the piece
    contour = mask.filter(ImageFilter.FIND_EDGES)
    border = Image.new('RGBA', (total_piece_w, total_piece_h), (255, 255, 255, 190))
    piece_rgba.paste(border, (0, 0), mask=contour)

    # 2. Draw slot cutout on background
    bg_rgba = base_img.convert('RGBA')

    # Dark translucent slot
    dark_overlay = Image.new('RGBA', (total_piece_w, total_piece_h), (12, 10, 24, 205))
    slot_layer = Image.new('RGBA', bg_rgba.size, (0, 0, 0, 0))
    slot_layer.paste(dark_overlay, (slot_x - pad, slot_y - pad), mask=mask)
    bg_rgba = Image.alpha_composite(bg_rgba, slot_layer)

    # Subtle bright stroke around the slot so it's clearly visible
    slot_stroke_layer = Image.new('RGBA', bg_rgba.size, (0, 0, 0, 0))
    slot_stroke = Image.new('RGBA', (total_piece_w, total_piece_h), (255, 255, 255, 220))
    slot_stroke_layer.paste(slot_stroke, (slot_x - pad, slot_y - pad), mask=contour)
    bg_rgba = Image.alpha_composite(bg_rgba, slot_stroke_layer)

    # Encode background to base64 JPEG
    bg_buf = io.BytesIO()
    bg_rgba.convert('RGB').save(bg_buf, format='JPEG', quality=88)
    bg_b64 = "data:image/jpeg;base64," + base64.b64encode(bg_buf.getvalue()).decode('utf-8')

    # Encode piece to base64 PNG (transparency preserved)
    piece_buf = io.BytesIO()
    piece_rgba.save(piece_buf, format='PNG')
    piece_b64 = "data:image/png;base64," + base64.b64encode(piece_buf.getvalue()).decode('utf-8')

    # Fallback math question for accessibility / keyboard navigation
    num1 = random.randint(3, 12)
    num2 = random.randint(2, 9)
    fallback_q = f"{num1} + {num2} = ?"
    fallback_a = str(num1 + num2)

    challenge_id = "chl_" + secrets.token_urlsafe(20)

    return {
        "challenge_id": challenge_id,
        "bg_image": bg_b64,
        "piece_image": piece_b64,
        "correct_x": slot_x,
        "correct_y": slot_y,
        "piece_y": slot_y,
        "piece_w": total_piece_w,
        "piece_h": total_piece_h,
        "fallback_question": fallback_q,
        "fallback_answer": fallback_a,
        "width": width,
        "height": height
    }
