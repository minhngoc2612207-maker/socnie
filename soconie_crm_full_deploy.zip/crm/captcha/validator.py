"""
CAPTCHA Validator for Soconie CRM.
Performs server-side validation of slider puzzle position, drag trajectories,
anti-replay checks, and single-use token issuance.
"""
import math
import secrets
import hashlib
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple

from crm.database import query_db, execute_db
from crm.site_config import (
    CAPTCHA_TOLERANCE_PX,
    CAPTCHA_TTL_SECONDS,
    CAPTCHA_MAX_FAILS,
    CAPTCHA_LOCK_MINUTES
)


def _compute_trail_hash(trail: List[Dict[str, Any]]) -> str:
    """Computes a deterministic hash of coordinates to detect automated replay attacks."""
    s = ",".join(f"{p.get('x', 0):.1f}:{p.get('y', 0):.1f}" for p in trail)
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def check_ip_locked(ip_address: str) -> Optional[int]:
    """Returns minutes remaining if IP is locked due to consecutive failures, else None."""
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    rec = query_db("""
        SELECT locked_until, failed_count FROM captcha_attempts 
        WHERE ip_address = ? AND locked_until > ?
    """, (ip_address, now_str), one=True)
    if rec:
        locked_dt = datetime.strptime(rec["locked_until"], "%Y-%m-%d %H:%M:%S")
        mins = max(1, int((locked_dt - datetime.now()).total_seconds() / 60))
        return mins
    return None


def record_failure(ip_address: str):
    """Increments failed attempt count and locks IP if threshold reached."""
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    rec = query_db("SELECT failed_count FROM captcha_attempts WHERE ip_address = ?", (ip_address,), one=True)
    if rec:
        new_count = rec["failed_count"] + 1
        if new_count >= CAPTCHA_MAX_FAILS:
            lock_until = (datetime.now() + timedelta(minutes=CAPTCHA_LOCK_MINUTES)).strftime("%Y-%m-%d %H:%M:%S")
            execute_db("""
                UPDATE captcha_attempts 
                SET failed_count = ?, locked_until = ?, updated_at = ? 
                WHERE ip_address = ?
            """, (new_count, lock_until, now_str, ip_address))
        else:
            execute_db("""
                UPDATE captcha_attempts 
                SET failed_count = ?, updated_at = ? 
                WHERE ip_address = ?
            """, (new_count, now_str, ip_address))
    else:
        execute_db("""
            INSERT INTO captcha_attempts (ip_address, failed_count, locked_until, updated_at)
            VALUES (?, 1, NULL, ?)
        """, (ip_address, now_str))


def reset_failure(ip_address: str):
    """Clears failure count for IP on successful completion."""
    execute_db("DELETE FROM captcha_attempts WHERE ip_address = ?", (ip_address,))


def validate_trajectory(trail: List[Dict[str, Any]]) -> Tuple[bool, str]:
    """
    Analyzes mouse / touch drag trajectory for authentic human dynamics.
    Rejects instant teleports, flat bots, and synthetic linear paths.
    """
    if not trail or not isinstance(trail, list):
        return False, "Thiếu dữ liệu quỹ đạo kéo."

    if len(trail) < 4:
        return False, "Quỹ đạo kéo quá ngắn, nghi ngờ tự động hóa."

    try:
        t_start = float(trail[0].get("t", 0))
        t_end = float(trail[-1].get("t", 0))
    except (ValueError, TypeError):
        return False, "Dữ liệu thời gian không hợp lệ."

    duration_ms = t_end - t_start
    # Human drag cannot physically be done under 350ms or longer than 60s
    if duration_ms < 350:
        return False, "Tốc độ kéo nhanh bất thường (dưới 350ms)."
    if duration_ms > 60000:
        return False, "Thời gian kéo quá dài. Vui lòng thử lại."

    # Check velocity changes (humans accelerate from rest, decelerate near target)
    x_coords = [float(p.get("x", 0)) for p in trail]
    y_coords = [float(p.get("y", 0)) for p in trail]

    dx_list = [x_coords[i+1] - x_coords[i] for i in range(len(x_coords)-1)]
    
    # Pure linear bots will have identical dx per step
    if len(set(round(d, 2) for d in dx_list)) <= 1 and len(dx_list) > 6:
        return False, "Quỹ đạo di chuyển thẳng hàng tuyệt đối (bot)."

    return True, "Hợp lệ"


def verify_captcha_challenge(
    challenge_id: str,
    final_x: float,
    trail: Optional[List[Dict[str, Any]]] = None,
    fallback_answer: Optional[str] = None,
    action: str = "register",
    ip_address: str = "127.0.0.1"
) -> Dict[str, Any]:
    """
    Main verification pipeline.
    Validates challenge status, coordinates, trajectory, or accessibility fallback.
    Returns: { success: bool, message: str, captcha_token: Optional[str] }
    """
    # 1. Check IP lock
    mins_locked = check_ip_locked(ip_address)
    if mins_locked:
        return {
            "success": False,
            "message": f"Địa chỉ IP đang bị khóa tạm thời do sai quá {CAPTCHA_MAX_FAILS} lần. Thử lại sau {mins_locked} phút.",
            "captcha_token": None
        }

    now = datetime.now()
    now_str = now.strftime("%Y-%m-%d %H:%M:%S")

    # 2. Retrieve challenge record
    rec = query_db("""
        SELECT * FROM captcha_challenges 
        WHERE challenge_id = ? AND is_used = 0 AND expires_at > ?
    """, (challenge_id, now_str), one=True)

    if not rec:
        record_failure(ip_address)
        return {
            "success": False,
            "message": "Thử thách không tồn tại hoặc đã hết hạn (2 phút). Vui lòng làm mới ảnh!",
            "captcha_token": None
        }

    # Mark challenge as used immediately (single-use token protection)
    execute_db("UPDATE captcha_challenges SET is_used = 1 WHERE challenge_id = ?", (challenge_id,))

    # 3. Path A: Accessibility Fallback (Math / Text)
    if fallback_answer is not None and str(fallback_answer).strip():
        correct_answer = str(rec.get("fallback_answer", "")).strip()
        if str(fallback_answer).strip() == correct_answer:
            reset_failure(ip_address)
            token = issue_captcha_token(action=action, ip_address=ip_address)
            return {
                "success": True,
                "message": "Xác nhận thành công!",
                "captcha_token": token
            }
        else:
            record_failure(ip_address)
            return {
                "success": False,
                "message": "Câu trả lời phép tính chưa chính xác. Vui lòng thử lại!",
                "captcha_token": None
            }

    # 4. Path B: Slider Puzzle Drag Position
    correct_x = float(rec["correct_x"])
    tolerance = float(CAPTCHA_TOLERANCE_PX)

    try:
        final_x_val = float(final_x)
    except (ValueError, TypeError):
        record_failure(ip_address)
        return {"success": False, "message": "Dữ liệu tọa độ không hợp lệ.", "captcha_token": None}

    diff = abs(final_x_val - correct_x)
    if diff > tolerance:
        record_failure(ip_address)
        return {
            "success": False,
            "message": f"Chưa đúng vị trí (lệch {diff:.1f}px). Hãy kéo mảnh ghép khớp vào vùng khuyết!",
            "captcha_token": None
        }

    # 5. Trajectory Verification
    if trail:
        valid_traj, reason = validate_trajectory(trail)
        if not valid_traj:
            record_failure(ip_address)
            return {
                "success": False,
                "message": f"Xác thực bất thường: {reason}",
                "captcha_token": None
            }

    # Passed! Reset failure count and issue single-use token
    reset_failure(ip_address)
    token = issue_captcha_token(action=action, ip_address=ip_address)

    return {
        "success": True,
        "message": "Đã xác nhận bạn không phải robot!",
        "captcha_token": token
    }


def issue_captcha_token(action: str = "register", ip_address: str = "127.0.0.1") -> str:
    """Generates a cryptographic single-use token valid for 2 minutes."""
    token = "cap_" + secrets.token_urlsafe(32)
    now = datetime.now()
    now_str = now.strftime("%Y-%m-%d %H:%M:%S")
    expires_at = (now + timedelta(seconds=CAPTCHA_TTL_SECONDS)).strftime("%Y-%m-%d %H:%M:%S")

    execute_db("""
        INSERT INTO captcha_tokens (token, action, ip_address, expires_at, is_used, created_at)
        VALUES (?, ?, ?, ?, 0, ?)
    """, (token, action, ip_address, expires_at, now_str))

    return token


def consume_captcha_token(token: str, action: str, ip_address: str = "127.0.0.1") -> bool:
    """
    Validates and consumes a single-use token before completing sensitive auth actions.
    Ensures token is not expired and matches required action.
    """
    if not token:
        return False

    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    rec = query_db("""
        SELECT id FROM captcha_tokens 
        WHERE token = ? AND action = ? AND is_used = 0 AND expires_at > ?
    """, (token, action, now_str), one=True)

    if not rec:
        return False

    # Consume immediately
    execute_db("UPDATE captcha_tokens SET is_used = 1 WHERE id = ?", (rec["id"],))
    return True
