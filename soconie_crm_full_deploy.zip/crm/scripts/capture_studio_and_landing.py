"""
Capture comprehensive screenshots of Soconie CRM Landing Page Fixes and Analysis Studio (5 Steps)
"""
import os
import io
import time
import shutil
import tempfile
import subprocess
import requests

chrome_path = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
artifact_dir = r"C:\Users\THC\.gemini\antigravity\brain\985b2eed-7902-4b89-b84c-58315124fe59"
temp_dir = tempfile.gettempdir()

# First create a shared report to get a valid share token for capture
share_token = "demo_report_token"
try:
    r_save = requests.post("http://localhost:5000/api/analysis/save-report", json={
        "title": "Báo Cáo Phân Tích Mẫu 2026",
        "summary": "Tóm tắt hiệu suất bán hàng và phân bổ khách hàng Pareto.",
        "dataset_name": "CRM_Kinh_Doanh_Mau_2026.csv",
        "report_data": {
            "title": "Báo Cáo Phân Tích Mẫu 2026",
            "summary": "Tóm tắt hiệu suất bán hàng và phân bổ khách hàng Pareto.",
            "kpis": {"total_revenue": 568000000, "total_records": 15, "win_rate": 47},
            "insight_chain": [
                {"tier": "DỮ LIỆU", "badge": "Khách quan", "content": "15 hợp đồng với tổng doanh số 568.000.000 đ."},
                {"tier": "THÔNG TIN", "badge": "So sánh", "content": "Doanh số bình quân 37.866.667 đ/khách hàng."},
                {"tier": "INSIGHT", "badge": "Nguyên nhân gốc rễ", "content": "Kênh Giới thiệu đạt tỷ lệ chốt cao nhất (75%)."},
                {"tier": "QUYẾT ĐỊNH", "badge": "Hành động ngay", "content": "Thiết lập chính sách hoa hồng 8% cho đối tác giới thiệu."}
            ]
        }
    }, timeout=5)
    if r_save.status_code == 200:
        share_token = r_save.json().get("share_token", share_token)
except Exception as e:
    print("Could not create test report:", e)

targets = [
    # 1. Landing Hero & 3 Cards (Light & Dark)
    ("shot_landing_cards_light.png", "http://localhost:5000/?theme=light", 1440, 1050),
    ("shot_landing_cards_dark.png", "http://localhost:5000/?theme=dark", 1440, 1050),

    # 2. Landing New Sections (#tinh-nang, #quy-trinh, #bang-gia, #gioi-thieu, #lien-he)
    ("shot_landing_sections_light.png", "http://localhost:5000/?theme=light#tinh-nang", 1440, 3600),
    ("shot_landing_sections_dark.png", "http://localhost:5000/?theme=dark#tinh-nang", 1440, 3600),
    ("shot_landing_contact_form.png", "http://localhost:5000/?theme=light#lien-he", 1440, 1200),

    # 3. Analysis Studio: Step 1 (Nhập dữ liệu)
    ("shot_studio_step1_light.png", "http://localhost:5000/khong-gian-phan-tich?step=1&theme=light", 1440, 1150),
    ("shot_studio_step1_dark.png", "http://localhost:5000/khong-gian-phan-tich?step=1&theme=dark", 1440, 1150),

    # 4. Analysis Studio: Step 2 (Làm sạch)
    ("shot_studio_step2_light.png", "http://localhost:5000/khong-gian-phan-tich?step=2&theme=light", 1440, 1200),

    # 5. Analysis Studio: Step 3 (Công cụ AI)
    ("shot_studio_step3_light.png", "http://localhost:5000/khong-gian-phan-tich?step=3&theme=light", 1440, 1200),

    # 6. Analysis Studio: Step 4 (Phân tích dữ liệu & Funnel)
    ("shot_studio_step4_light.png", "http://localhost:5000/khong-gian-phan-tich?step=4&theme=light", 1440, 1250),

    # 7. Analysis Studio: Step 5 (Báo cáo & Xuất tệp)
    ("shot_studio_step5_light.png", "http://localhost:5000/khong-gian-phan-tich?step=5&theme=light", 1440, 1200),

    # 8. Shared Report View (Báo cáo chia sẻ công khai)
    ("shot_studio_shared_report.png", f"http://localhost:5000/bao-cao/chia-se/{share_token}?theme=light", 1440, 1100),

    # 9. Mobile Responsive Landing & Studio
    ("shot_mobile_landing_sections.png", "http://localhost:5000/?theme=light", 390, 3200),
    ("shot_mobile_studio_step1.png", "http://localhost:5000/khong-gian-phan-tich?step=1&theme=light", 390, 1400),
]

for filename, url, w, h in targets:
    tmp_out = os.path.join(temp_dir, "tmp_" + filename)
    if os.path.exists(tmp_out):
        try:
            os.remove(tmp_out)
        except:
            pass

    cmd = [
        chrome_path,
        "--headless=new",
        "--disable-gpu",
        "--no-sandbox",
        f"--window-size={w},{h}",
        "--hide-scrollbars",
        "--virtual-time-budget=3500",
        f"--screenshot={tmp_out}",
        url
    ]
    try:
        subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=25)
        dst = os.path.join(artifact_dir, filename)
        if os.path.exists(tmp_out):
            shutil.copyfile(tmp_out, dst)
            sz = os.path.getsize(dst)
            print(f"[OK] Captured {filename}: {sz:,} bytes ({w}x{h})")
        else:
            print(f"[FAIL] Could not generate {filename}")
    except Exception as e:
        print(f"[ERROR] Capturing {filename}:", e)
