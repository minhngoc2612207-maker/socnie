with open('crm/scratch__app.mjs.txt', 'r', encoding='utf-8') as f:
    js = f.read()

import re

# Find step definitions
print("=== STEPS & LABELS ===")
for m in re.finditer(r'\{[^{}]*id:\s*["\']([^"\']+)["\'][^{}]*name:\s*["\']([^"\']+)["\'][^{}]*\}', js):
    print(m.group(0)[:120])

print("\n=== RENDER VIEWS ===")
for m in re.finditer(r'function render([A-Za-z0-9_]+)\(', js):
    print(m.group(1))
