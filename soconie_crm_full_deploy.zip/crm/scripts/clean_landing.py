with open('crm/templates/landing.html', 'r', encoding='utf-8') as f:
    text = f.read()

# Pattern for the modal block that was repeated
block_start = '    <!-- ========================================================\n         MODAL 1: GIỚI THIỆU TÍNH NĂNG KHÁCH HÀNG 360° (DEMO MẪU)'
block_end = '        </div>\n    </div>\n'

# Find all occurrences of the modal block
parts = text.split(block_start)
print(f'Total parts: {len(parts)}')

if len(parts) == 5:
    # parts[0] had block inserted after "        </div>\n    </div>\n"
    # Extract the modal code from one of the parts
    modal_code = block_start + parts[1].split('    <!-- ========================================================')[0]
    
    # Clean parts 0, 1, 2, 3 by stripping the modal block tail
    cleaned_part0 = parts[0]
    
    # For parts 1, 2, 3: remove the modal content up to its closing </div>\n    </div>\n
    cleaned_part1 = parts[1][parts[1].find('    <!-- ========================================================'):]
    cleaned_part2 = parts[2][parts[2].find('    <!-- ========================================================'):]
    cleaned_part3 = parts[3][parts[3].find('    <!-- ========================================================'):]
    
    # In part 4, we want to KEEP the modal block right before TOAST
    # Let's inspect where TOAST is
    cleaned_text = cleaned_part0 + cleaned_part1 + cleaned_part2 + cleaned_part3 + block_start + parts[4]
    
    with open('crm/templates/landing.html', 'w', encoding='utf-8') as f:
        f.write(cleaned_text)
    print('Cleaned landing.html successfully!')
else:
    print('Unexpected part count, checking pattern.')
