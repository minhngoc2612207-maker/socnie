"""
System Settings, User Management, RBAC, Profile & Audit Routes.
"""
import uuid
from flask import Blueprint, render_template, request, redirect, url_for, flash, abort
from crm.auth import login_required, permission_required, get_current_user, log_audit, hash_password, verify_password
from crm.database import query_db, execute_db

system_bp = Blueprint("system", __name__)


# ---------------------------------------------------------------------
# CÀI ĐẶT & PHÂN QUYỀN (/cai-dat)
# ---------------------------------------------------------------------
@system_bp.route("/cai-dat")
@login_required
@permission_required("settings", "view")
def settings_view():
    users = query_db("""
        SELECT u.*, r.name as role_name, r.code as role_code, d.name as department_name 
        FROM users u 
        LEFT JOIN roles r ON u.role_id = r.id 
        LEFT JOIN departments d ON u.department_id = d.id 
        WHERE u.deleted_at IS NULL 
        ORDER BY u.created_at DESC
    """)
    roles = query_db("SELECT * FROM roles WHERE deleted_at IS NULL ORDER BY created_at")
    departments = query_db("SELECT * FROM departments WHERE deleted_at IS NULL ORDER BY name")
    stages = query_db("SELECT * FROM pipeline_stages ORDER BY order_index")
    
    settings_rows = query_db("SELECT key, value FROM settings")
    settings_dict = {r["key"]: r["value"] for r in settings_rows}

    return render_template(
        "system/settings.html",
        active_page="settings",
        users=users,
        roles=roles,
        departments=departments,
        stages=stages,
        settings_dict=settings_dict
    )


@system_bp.route("/cai-dat/nguoi-dung/luu", methods=["POST"])
@login_required
@permission_required("users", "create")
def save_user():
    user_id = request.form.get("user_id", "").strip()
    full_name = request.form.get("full_name", "").strip()
    username = request.form.get("username", "").strip()
    password = request.form.get("password", "").strip()
    email = request.form.get("email", "").strip()
    phone = request.form.get("phone", "").strip()
    role_id = request.form.get("role_id", "").strip()
    department_id = request.form.get("department_id", "").strip() or None
    status = request.form.get("status", "active")

    if not full_name or not username:
        flash("Vui lòng điền đầy đủ Họ tên và Tên đăng nhập!", "danger")
        return redirect(url_for("system.settings_view"))

    if user_id:
        # Edit existing user
        existing = query_db("SELECT * FROM users WHERE id = ?", (user_id,), one=True)
        if not existing:
            flash("Người dùng không tồn tại!", "danger")
            return redirect(url_for("system.settings_view"))

        if password:
            execute_db("""
                UPDATE users SET full_name = ?, email = ?, phone = ?, role_id = ?, department_id = ?, status = ?, password_hash = ?, updated_at = datetime('now')
                WHERE id = ?
            """, (full_name, email, phone, role_id, department_id, status, hash_password(password), user_id))
        else:
            execute_db("""
                UPDATE users SET full_name = ?, email = ?, phone = ?, role_id = ?, department_id = ?, status = ?, updated_at = datetime('now')
                WHERE id = ?
            """, (full_name, email, phone, role_id, department_id, status, user_id))

        log_audit("UPDATE", "users", user_id, before_data=dict(existing), after_data={"full_name": full_name, "role_id": role_id, "status": status})
        flash(f"Đã cập nhật thông tin thành viên '{full_name}' thành công!", "success")
    else:
        # Create new user
        dup = query_db("SELECT id FROM users WHERE username = ? OR (email = ? AND email != '')", (username, email), one=True)
        if dup:
            flash("Tên đăng nhập hoặc email đã tồn tại trong hệ thống!", "danger")
            return redirect(url_for("system.settings_view"))

        if not password:
            flash("Vui lòng nhập mật khẩu khởi tạo cho tài khoản mới!", "danger")
            return redirect(url_for("system.settings_view"))

        new_id = f"u-{uuid.uuid4().hex[:8]}"
        execute_db("""
            INSERT INTO users (id, username, password_hash, full_name, email, phone, role_id, department_id, status, is_superadmin, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, datetime('now'), datetime('now'))
        """, (new_id, username, hash_password(password), full_name, email, phone, role_id, department_id, status))

        log_audit("CREATE", "users", new_id, after_data={"username": username, "full_name": full_name, "role_id": role_id})
        flash(f"Đã tạo mới thành viên '{full_name}' ({username}) thành công!", "success")

    return redirect(url_for("system.settings_view"))


@system_bp.route("/cai-dat/nguoi-dung/<user_id>/xoa", methods=["POST"])
@login_required
@permission_required("users", "delete")
def delete_user(user_id):
    current = get_current_user()
    if user_id == current["id"]:
        flash("Bạn không thể tự xóa tài khoản của chính mình!", "danger")
        return redirect(url_for("system.settings_view"))

    target = query_db("SELECT * FROM users WHERE id = ?", (user_id,), one=True)
    if not target:
        flash("Người dùng không tồn tại!", "danger")
        return redirect(url_for("system.settings_view"))

    if target.get("is_superadmin"):
        flash("Không thể xóa tài khoản Quản trị viên cấp cao (Superadmin)!", "danger")
        return redirect(url_for("system.settings_view"))

    # Soft delete
    execute_db("UPDATE users SET deleted_at = datetime('now') WHERE id = ?", (user_id,))
    log_audit("DELETE", "users", user_id, before_data=dict(target))
    flash(f"Đã xóa thành viên '{target['full_name']}' thành công (Xóa mềm)! Dữ liệu cũ vẫn được bảo lưu an toàn.", "success")
    return redirect(url_for("system.settings_view"))


@system_bp.route("/cai-dat/cong-ty", methods=["POST"])
@login_required
@permission_required("settings", "edit")
def save_company_settings():
    keys = ["company_name", "tax_id", "company_phone", "company_email", "company_address", "brand_color"]
    for k in keys:
        val = request.form.get(k, "").strip()
        execute_db("""
            INSERT INTO settings (key, value, category, updated_at)
            VALUES (?, ?, 'company', datetime('now'))
            ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
        """, (k, val))

    log_audit("UPDATE", "settings", "company_info", after_data={"company_name": request.form.get("company_name")})
    flash("Đã lưu thông tin doanh nghiệp thành công!", "success")
    return redirect(url_for("system.settings_view"))


# ---------------------------------------------------------------------
# HỒ SƠ CÁ NHÂN (/ho-so)
# ---------------------------------------------------------------------
@system_bp.route("/ho-so")
@login_required
def profile_view():
    return render_template("system/profile.html", active_page="profile")


@system_bp.route("/ho-so/cap-nhat", methods=["POST"])
@login_required
def update_profile():
    current = get_current_user()
    full_name = request.form.get("full_name", "").strip()
    email = request.form.get("email", "").strip()
    phone = request.form.get("phone", "").strip()

    if not full_name:
        flash("Họ tên không được để trống!", "danger")
        return redirect(url_for("system.profile_view"))

    execute_db("""
        UPDATE users SET full_name = ?, email = ?, phone = ?, updated_at = datetime('now')
        WHERE id = ?
    """, (full_name, email, phone, current["id"]))

    log_audit("UPDATE", "profile", current["id"], after_data={"full_name": full_name, "email": email, "phone": phone})
    flash("Cập nhật thông tin cá nhân thành công!", "success")
    return redirect(url_for("system.profile_view"))


@system_bp.route("/ho-so/doi-mat-khau", methods=["POST"])
@login_required
def change_password():
    current = get_current_user()
    current_pass = request.form.get("current_password", "")
    new_pass = request.form.get("new_password", "")
    confirm_pass = request.form.get("confirm_password", "")

    if not verify_password(current_pass, current["password_hash"]):
        flash("Mật khẩu hiện tại không chính xác!", "danger")
        return redirect(url_for("system.profile_view"))

    if len(new_pass) < 6:
        flash("Mật khẩu mới phải có tối thiểu 6 ký tự!", "danger")
        return redirect(url_for("system.profile_view"))

    if new_pass != confirm_pass:
        flash("Xác nhận mật khẩu mới không trùng khớp!", "danger")
        return redirect(url_for("system.profile_view"))

    execute_db("UPDATE users SET password_hash = ?, updated_at = datetime('now') WHERE id = ?", (hash_password(new_pass), current["id"]))
    log_audit("CHANGE_PASSWORD", "users", current["id"])
    flash("Đổi mật khẩu thành công! Hãy ghi nhớ mật khẩu mới của bạn.", "success")
    return redirect(url_for("system.profile_view"))


# ---------------------------------------------------------------------
# NHẬT KÝ KIỂM TOÁN (/nhat-ky)
# ---------------------------------------------------------------------
@system_bp.route("/nhat-ky")
@login_required
def audit_logs_view():
    logs = query_db("SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 100")
    return render_template("system/audit_logs.html", active_page="audit_logs", logs=logs)


# ---------------------------------------------------------------------
# THÔNG BÁO (/thong-bao)
# ---------------------------------------------------------------------
@system_bp.route("/thong-bao")
@login_required
def notifications_view():
    current = get_current_user()
    notifs = query_db("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC", (current["id"],))
    return render_template(
        "shared/placeholder_page.html",
        active_page="notifications",
        page_title="Trung Tâm Thông Báo",
        page_subtitle="Thông báo hệ thống, nhắc hạn công việc và cập nhật tiến độ cơ hội",
        page_icon="fa-regular fa-bell",
        roadmap_stage="Hệ thống",
        sample_items=notifs
    )
