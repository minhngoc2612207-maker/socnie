"""
PartnerIQ Core Modules
"""
