"""
DataIQ - Enterprise Data Processing AI Agent
Orchestrates B1 to B7 Workflow:
B1: Intake & Validation
B2: Multimodal Reading, Profiling, Gemini Planning, Deterministic Cleaning, Problem Analysis
B3: Gatekeeper Decision
B4: Diagnostic Error Reporting
B5: Human-in-the-Loop Feedback, Scoped Reprocessing, Version Control & Lessons Learned
B6: User Evaluation & Quality Analytics
B7: Multi-format Export & Strategic Executive Briefing
"""
