"""
PartnerIQ & DataIQ Platform
Enterprise AI Agent System with Multi-tenant Workspaces, Human-in-the-Loop Feedback,
Deterministic Data Processing, and Automated Strategic Reporting.
"""

__version__ = "2.0.0"
