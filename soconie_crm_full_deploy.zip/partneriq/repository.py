"""
SQLite Repository & Data Access Layer for PartnerIQ & DataIQ.
Provides multi-tenant workspace isolation, schema migrations, audit trail,
job lifecycle persistence, versioned runs, change logs, findings, feedbacks,
lessons learned, and evaluation metrics.
"""

import os
import json
import sqlite3
import threading
from datetime import datetime
from typing import Dict, Any, List, Optional, Tuple

import tempfile

def _resolve_db_path() -> str:
    is_cloud_serverless = bool(
        os.environ.get("VERCEL") or
        os.environ.get("AWS_LAMBDA_FUNCTION_NAME") or
        os.environ.get("VERCEL_ENV") or
        os.environ.get("NOW_REGION")
    )
    if is_cloud_serverless:
        target_dir = os.path.join(tempfile.gettempdir(), "partneriq_data")
        os.makedirs(target_dir, exist_ok=True)
        return os.path.join(target_dir, "partneriq.db")

    default_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "partneriq.db")
    try:
        os.makedirs(os.path.dirname(default_path), exist_ok=True)
        test_file = os.path.join(os.path.dirname(default_path), ".perm_test")
        with open(test_file, "w") as f:
            f.write("1")
        os.remove(test_file)
        return default_path
    except Exception:
        target_dir = os.path.join(tempfile.gettempdir(), "partneriq_data")
        os.makedirs(target_dir, exist_ok=True)
        return os.path.join(target_dir, "partneriq.db")

DB_PATH = _resolve_db_path()
_local = threading.local()


def get_db_connection() -> sqlite3.Connection:
    """Thread-local SQLite connection with row factory and serverless-safe journal mode."""
    if not hasattr(_local, "conn") or _local.conn is None:
        global DB_PATH
        try:
            os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        except Exception:
            DB_PATH = os.path.join(tempfile.gettempdir(), "partneriq_data", "partneriq.db")
            os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

        conn = sqlite3.connect(DB_PATH, timeout=30.0)
        conn.row_factory = sqlite3.Row

        is_cloud_serverless = bool(
            os.environ.get("VERCEL") or
            os.environ.get("AWS_LAMBDA_FUNCTION_NAME") or
            os.environ.get("VERCEL_ENV")
        )
        if is_cloud_serverless:
            conn.execute("PRAGMA journal_mode=DELETE")
        else:
            conn.execute("PRAGMA journal_mode=WAL")

        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA foreign_keys=ON")
        _local.conn = conn
    return _local.conn


def init_db():
    """Initializes all database tables and seeds default multi-tenant workspace and users."""
    conn = get_db_connection()
    cursor = conn.cursor()

    # 1. Workspaces
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS workspaces (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        industry TEXT,
        brand_color TEXT DEFAULT '#4f46e5',
        logo_url TEXT,
        config_json TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """)

    # 2. Users & Roles
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        workspace_id TEXT NOT NULL,
        username TEXT UNIQUE NOT NULL,
        full_name TEXT NOT NULL,
        email TEXT,
        role TEXT NOT NULL CHECK(role IN ('admin', 'staff', 'viewer')),
        created_at TEXT NOT NULL,
        FOREIGN KEY (workspace_id) REFERENCES workspaces(id)
    )
    """)

    # 3. Audit Logs
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS audit_logs (
        id TEXT PRIMARY KEY,
        workspace_id TEXT NOT NULL,
        user_id TEXT,
        user_name TEXT,
        user_role TEXT,
        action TEXT NOT NULL,
        target_type TEXT NOT NULL,
        target_id TEXT,
        before_state TEXT,
        after_state TEXT,
        details TEXT,
        created_at TEXT NOT NULL
    )
    """)

    # 4. Data Jobs
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS data_jobs (
        id TEXT PRIMARY KEY,
        workspace_id TEXT NOT NULL,
        created_by TEXT,
        title TEXT NOT NULL,
        business_context TEXT,
        problem_statement TEXT NOT NULL,
        goals TEXT,
        column_descriptions TEXT,
        mask_sensitive INTEGER DEFAULT 1,
        status TEXT NOT NULL CHECK(status IN ('DRAFT', 'PROCESSING', 'FAILED', 'READY_FOR_REVIEW', 'REPROCESSING', 'REVIEWED', 'EXPORTED')),
        current_run_version INTEGER DEFAULT 1,
        progress_percent INTEGER DEFAULT 0,
        current_stage TEXT DEFAULT 'Chờ xử lý',
        error_summary TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (workspace_id) REFERENCES workspaces(id)
    )
    """)

    # 5. Data Files
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS data_files (
        id TEXT PRIMARY KEY,
        job_id TEXT NOT NULL,
        workspace_id TEXT NOT NULL,
        filename TEXT NOT NULL,
        original_filename TEXT NOT NULL,
        file_path TEXT NOT NULL,
        file_type TEXT NOT NULL,
        file_size INTEGER DEFAULT 0,
        sheet_names TEXT,
        row_count INTEGER DEFAULT 0,
        col_count INTEGER DEFAULT 0,
        created_at TEXT NOT NULL,
        FOREIGN KEY (job_id) REFERENCES data_jobs(id) ON DELETE CASCADE,
        FOREIGN KEY (workspace_id) REFERENCES workspaces(id)
    )
    """)

    # 6. Job Runs (Versions v1, v2, ...)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS job_runs (
        id TEXT PRIMARY KEY,
        job_id TEXT NOT NULL,
        workspace_id TEXT NOT NULL,
        version INTEGER NOT NULL,
        trigger_type TEXT DEFAULT 'INITIAL',
        gatekeeper_decision TEXT,
        gatekeeper_notes TEXT,
        plan_json TEXT,
        profiling_json TEXT,
        clean_data_path TEXT,
        clean_data_preview TEXT,
        report_markdown TEXT,
        report_sections_json TEXT,
        ai_source_badge TEXT DEFAULT 'GEMINI_AI',
        diff_summary_json TEXT,
        reprocess_summary TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (job_id) REFERENCES data_jobs(id) ON DELETE CASCADE,
        FOREIGN KEY (workspace_id) REFERENCES workspaces(id)
    )
    """)

    # 7. Change Logs
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS change_logs (
        id TEXT PRIMARY KEY,
        run_id TEXT NOT NULL,
        job_id TEXT NOT NULL,
        workspace_id TEXT NOT NULL,
        file_name TEXT,
        sheet_name TEXT,
        row_index INTEGER,
        col_name TEXT,
        old_value TEXT,
        new_value TEXT,
        change_type TEXT,
        reason TEXT,
        source TEXT NOT NULL CHECK(source IN ('RULE', 'AI')),
        created_at TEXT NOT NULL
    )
    """)

    # 8. Findings
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS findings (
        id TEXT PRIMARY KEY,
        run_id TEXT NOT NULL,
        job_id TEXT NOT NULL,
        workspace_id TEXT NOT NULL,
        title TEXT NOT NULL,
        severity TEXT NOT NULL CHECK(severity IN ('CRITICAL', 'HIGH', 'MEDIUM', 'LOW')),
        category TEXT NOT NULL,
        description TEXT,
        evidence_refs TEXT,
        impact_estimate TEXT,
        recommendation TEXT,
        source TEXT NOT NULL CHECK(source IN ('RULE', 'AI')),
        created_at TEXT NOT NULL
    )
    """)

    # 9. Feedbacks
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS feedbacks (
        id TEXT PRIMARY KEY,
        job_id TEXT NOT NULL,
        run_id TEXT NOT NULL,
        workspace_id TEXT NOT NULL,
        user_id TEXT,
        level TEXT NOT NULL CHECK(level IN ('REPORT', 'FINDING', 'CELL')),
        target_ref TEXT,
        error_category TEXT NOT NULL,
        user_comment TEXT NOT NULL,
        expected_value TEXT,
        attachment_path TEXT,
        priority TEXT DEFAULT 'MEDIUM',
        status TEXT DEFAULT 'PENDING' CHECK(status IN ('PENDING', 'APPLIED', 'REJECTED_CONFLICT', 'OVERRIDDEN')),
        agent_resolution_notes TEXT,
        conflict_evidence TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (job_id) REFERENCES data_jobs(id) ON DELETE CASCADE
    )
    """)

    # 10. Lessons Learned
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS lessons (
        id TEXT PRIMARY KEY,
        workspace_id TEXT NOT NULL,
        source_job_id TEXT,
        source_feedback_id TEXT,
        category TEXT NOT NULL,
        rule_key TEXT NOT NULL,
        rule_content TEXT NOT NULL,
        is_active INTEGER DEFAULT 1,
        created_by TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (workspace_id) REFERENCES workspaces(id)
    )
    """)

    # 11. Evaluations
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS evaluations (
        id TEXT PRIMARY KEY,
        job_id TEXT NOT NULL,
        run_id TEXT NOT NULL,
        workspace_id TEXT NOT NULL,
        user_id TEXT,
        rating_stars INTEGER CHECK(rating_stars BETWEEN 1 AND 5),
        findings_decisions TEXT,
        confidence_score INTEGER,
        general_notes TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (job_id) REFERENCES data_jobs(id) ON DELETE CASCADE
    )
    """)

    # 12. Error Reports (For Gatekeeper / Branch B4)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS error_reports (
        id TEXT PRIMARY KEY,
        job_id TEXT NOT NULL,
        workspace_id TEXT NOT NULL,
        error_code TEXT NOT NULL,
        severity TEXT NOT NULL CHECK(severity IN ('BLOCKER', 'WARNING')),
        file_name TEXT,
        sheet_name TEXT,
        row_index INTEGER,
        col_name TEXT,
        offending_value TEXT,
        cause TEXT NOT NULL,
        suggested_fix TEXT,
        ai_explanation TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (job_id) REFERENCES data_jobs(id) ON DELETE CASCADE
    )
    """)

    conn.commit()
    seed_defaults(conn)


def seed_defaults(conn: sqlite3.Connection):
    """Seeds initial workspace and user accounts if empty."""
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM workspaces")
    if cursor.fetchone()[0] == 0:
        default_config = {
            "max_reprocess_rounds": 5,
            "error_threshold_percent": 40.0,
            "sensitive_masking_enabled": True,
            "allowed_file_types": [".csv", ".xlsx", ".xls", ".json", ".pdf", ".docx", ".txt"],
            "max_file_size_mb": 30,
            "brand_title": "Đại Thành Group BI Portal",
            "currency_symbol": "đ"
        }
        now = datetime.now().isoformat()
        cursor.execute("""
        INSERT INTO workspaces (id, name, industry, brand_color, logo_url, config_json, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            "ws-default",
            "Công ty CP Thiết bị Gia dụng Đại Thành",
            "Sản xuất & Bán lẻ Thiết bị Gia dụng",
            "#4f46e5",
            "/static/img/logo.png",
            json.dumps(default_config, ensure_ascii=False),
            now,
            now
        ))

        # Default users
        cursor.execute("""
        INSERT INTO users (id, workspace_id, username, full_name, email, role, created_at)
        VALUES 
        ('usr-admin', 'ws-default', 'admin', 'Quản trị viên Hệ thống', 'admin@daithanh.vn', 'admin', ?),
        ('usr-staff', 'ws-default', 'staff', 'Nguyễn Văn An (Chuyên viên)', 'an.nguyen@daithanh.vn', 'staff', ?),
        ('usr-viewer', 'ws-default', 'viewer', 'Lê Thị Bình (Giám đốc xem)', 'binh.le@daithanh.vn', 'viewer', ?)
        """, (now, now, now))

        # Initial seed lessons
        cursor.execute("""
        INSERT INTO lessons (id, workspace_id, category, rule_key, rule_content, is_active, created_by, created_at)
        VALUES 
        ('les-001', 'ws-default', 'COLUMN_SEMANTICS', 'col:doanh_thu_thuan', 'Cột Doanh thu thuần là số tiền bán hàng thực tế đã trừ chiết khấu nhưng chưa gồm 10% VAT', 1, 'admin', ?),
        ('les-002', 'ws-default', 'ENTITY_IDENTITY', 'entity:dai_ly_noi_bo', 'Mã đối tác bắt đầu bằng DL-NB hoặc NB- là chi nhánh nội bộ trực thuộc tập đoàn, không xếp vào đại lý công nợ bên ngoài', 1, 'admin', ?)
        """, (now, now))

        conn.commit()


# ========================================================
# WORKSPACE & USER APIS
# ========================================================

def get_workspace(workspace_id: str = "ws-default") -> Optional[Dict[str, Any]]:
    conn = get_db_connection()
    row = conn.execute("SELECT * FROM workspaces WHERE id = ?", (workspace_id,)).fetchone()
    if row:
        d = dict(row)
        d["config"] = json.loads(d.get("config_json") or "{}")
        return d
    return None


def list_workspaces() -> List[Dict[str, Any]]:
    conn = get_db_connection()
    rows = conn.execute("SELECT * FROM workspaces ORDER BY name ASC").fetchall()
    res = []
    for r in rows:
        d = dict(r)
        d["config"] = json.loads(d.get("config_json") or "{}")
        res.append(d)
    return res


def update_workspace_config(workspace_id: str, new_config: Dict[str, Any]) -> bool:
    conn = get_db_connection()
    ws = get_workspace(workspace_id)
    if not ws:
        return False
    merged = ws["config"]
    merged.update(new_config)
    now = datetime.now().isoformat()
    conn.execute(
        "UPDATE workspaces SET config_json = ?, updated_at = ? WHERE id = ?",
        (json.dumps(merged, ensure_ascii=False), now, workspace_id)
    )
    conn.commit()
    return True


def get_user(user_id: str) -> Optional[Dict[str, Any]]:
    conn = get_db_connection()
    row = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    return dict(row) if row else None


def list_users(workspace_id: str = "ws-default") -> List[Dict[str, Any]]:
    conn = get_db_connection()
    rows = conn.execute("SELECT * FROM users WHERE workspace_id = ? ORDER BY role ASC", (workspace_id,)).fetchall()
    return [dict(r) for r in rows]


# ========================================================
# AUDIT TRAIL
# ========================================================

def log_audit(
    workspace_id: str,
    action: str,
    target_type: str,
    target_id: Optional[str] = None,
    user_id: Optional[str] = None,
    user_name: Optional[str] = None,
    user_role: Optional[str] = None,
    before_state: Optional[Any] = None,
    after_state: Optional[Any] = None,
    details: str = ""
):
    """Inserts a structured immutable audit record."""
    conn = get_db_connection()
    audit_id = f"aud-{datetime.now().strftime('%Y%m%d%H%M%S')}-{os.urandom(4).hex()}"
    b_json = json.dumps(before_state, ensure_ascii=False) if before_state is not None else None
    a_json = json.dumps(after_state, ensure_ascii=False) if after_state is not None else None
    now = datetime.now().isoformat()
    conn.execute("""
    INSERT INTO audit_logs (id, workspace_id, user_id, user_name, user_role, action, target_type, target_id, before_state, after_state, details, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        audit_id, workspace_id, user_id, user_name, user_role, action, target_type, target_id, b_json, a_json, details, now
    ))
    conn.commit()


def get_audit_logs(workspace_id: str, target_id: Optional[str] = None, limit: int = 100) -> List[Dict[str, Any]]:
    conn = get_db_connection()
    if target_id:
        rows = conn.execute(
            "SELECT * FROM audit_logs WHERE workspace_id = ? AND target_id = ? ORDER BY created_at DESC LIMIT ?",
            (workspace_id, target_id, limit)
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM audit_logs WHERE workspace_id = ? ORDER BY created_at DESC LIMIT ?",
            (workspace_id, limit)
        ).fetchall()
    res = []
    for r in rows:
        d = dict(r)
        if d.get("before_state"):
            try:
                d["before_state"] = json.loads(d["before_state"])
            except Exception:
                pass
        if d.get("after_state"):
            try:
                d["after_state"] = json.loads(d["after_state"])
            except Exception:
                pass
        res.append(d)
    return res


# ========================================================
# DATA JOBS & LIFECYCLE
# ========================================================

def create_job(
    job_id: str,
    workspace_id: str,
    title: str,
    problem_statement: str,
    business_context: Dict[str, Any],
    goals: List[str],
    column_descriptions: Dict[str, str],
    mask_sensitive: bool = True,
    created_by: str = "staff"
) -> Dict[str, Any]:
    conn = get_db_connection()
    now = datetime.now().isoformat()
    conn.execute("""
    INSERT INTO data_jobs (
        id, workspace_id, created_by, title, business_context, problem_statement,
        goals, column_descriptions, mask_sensitive, status, current_run_version,
        progress_percent, current_stage, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'PROCESSING', 1, 5, 'Khởi tạo tác vụ', ?, ?)
    """, (
        job_id,
        workspace_id,
        created_by,
        title,
        json.dumps(business_context, ensure_ascii=False),
        problem_statement,
        json.dumps(goals, ensure_ascii=False),
        json.dumps(column_descriptions, ensure_ascii=False),
        1 if mask_sensitive else 0,
        now,
        now
    ))
    conn.commit()

    log_audit(
        workspace_id=workspace_id,
        action="CREATE_JOB",
        target_type="JOB",
        target_id=job_id,
        user_name=created_by,
        after_state={"status": "PROCESSING", "title": title},
        details=f"Tạo mới phiên xử lý dữ liệu: {title}"
    )
    return get_job(job_id)


def get_job(job_id: str) -> Optional[Dict[str, Any]]:
    conn = get_db_connection()
    row = conn.execute("SELECT * FROM data_jobs WHERE id = ?", (job_id,)).fetchone()
    if not row:
        return None
    d = dict(row)
    d["business_context"] = json.loads(d.get("business_context") or "{}")
    d["goals"] = json.loads(d.get("goals") or "[]")
    d["column_descriptions"] = json.loads(d.get("column_descriptions") or "{}")
    d["error_summary"] = json.loads(d.get("error_summary") or "{}")
    return d


def list_jobs(workspace_id: str = "ws-default", status: Optional[str] = None) -> List[Dict[str, Any]]:
    conn = get_db_connection()
    if status:
        rows = conn.execute(
            "SELECT * FROM data_jobs WHERE workspace_id = ? AND status = ? ORDER BY created_at DESC",
            (workspace_id, status)
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM data_jobs WHERE workspace_id = ? ORDER BY created_at DESC",
            (workspace_id,)
        ).fetchall()
    res = []
    for r in rows:
        d = dict(r)
        d["business_context"] = json.loads(d.get("business_context") or "{}")
        d["goals"] = json.loads(d.get("goals") or "[]")
        res.append(d)
    return res


def update_job_status(job_id: str, new_status: str, current_stage: Optional[str] = None, error_summary: Optional[Dict[str, Any]] = None, user_name: str = "system"):
    conn = get_db_connection()
    job = get_job(job_id)
    if not job:
        return
    old_status = job.get("status")
    now = datetime.now().isoformat()

    err_json = json.dumps(error_summary, ensure_ascii=False) if error_summary is not None else None
    if current_stage and err_json:
        conn.execute(
            "UPDATE data_jobs SET status = ?, current_stage = ?, error_summary = ?, updated_at = ? WHERE id = ?",
            (new_status, current_stage, err_json, now, job_id)
        )
    elif current_stage:
        conn.execute(
            "UPDATE data_jobs SET status = ?, current_stage = ?, updated_at = ? WHERE id = ?",
            (new_status, current_stage, now, job_id)
        )
    else:
        conn.execute(
            "UPDATE data_jobs SET status = ?, updated_at = ? WHERE id = ?",
            (new_status, now, job_id)
        )
    conn.commit()

    log_audit(
        workspace_id=job.get("workspace_id", "ws-default"),
        action="STATUS_CHANGE",
        target_type="JOB",
        target_id=job_id,
        user_name=user_name,
        before_state={"status": old_status},
        after_state={"status": new_status, "stage": current_stage},
        details=f"Chuyển trạng thái từ {old_status} sang {new_status}"
    )


def update_job_progress(job_id: str, progress_percent: int, stage_text: str):
    conn = get_db_connection()
    now = datetime.now().isoformat()
    conn.execute(
        "UPDATE data_jobs SET progress_percent = ?, current_stage = ?, updated_at = ? WHERE id = ?",
        (progress_percent, stage_text, now, job_id)
    )
    conn.commit()


# ========================================================
# DATA FILES
# ========================================================

def add_data_file(
    file_id: str,
    job_id: str,
    workspace_id: str,
    filename: str,
    original_filename: str,
    file_path: str,
    file_type: str,
    file_size: int = 0,
    sheet_names: Optional[List[str]] = None,
    row_count: int = 0,
    col_count: int = 0
):
    conn = get_db_connection()
    now = datetime.now().isoformat()
    conn.execute("""
    INSERT INTO data_files (
        id, job_id, workspace_id, filename, original_filename, file_path,
        file_type, file_size, sheet_names, row_count, col_count, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        file_id, job_id, workspace_id, filename, original_filename, file_path,
        file_type, file_size, json.dumps(sheet_names or [], ensure_ascii=False),
        row_count, col_count, now
    ))
    conn.commit()


def get_job_files(job_id: str) -> List[Dict[str, Any]]:
    conn = get_db_connection()
    rows = conn.execute("SELECT * FROM data_files WHERE job_id = ?", (job_id,)).fetchall()
    res = []
    for r in rows:
        d = dict(r)
        d["sheet_names"] = json.loads(d.get("sheet_names") or "[]")
        res.append(d)
    return res


# ========================================================
# JOB RUNS (VERSIONS)
# ========================================================

def create_run(
    run_id: str,
    job_id: str,
    workspace_id: str,
    version: int,
    trigger_type: str = "INITIAL",
    gatekeeper_decision: str = "CAN_PROCESS",
    gatekeeper_notes: str = "",
    plan_json: Optional[Dict[str, Any]] = None,
    profiling_json: Optional[Dict[str, Any]] = None,
    clean_data_path: str = "",
    clean_data_preview: Optional[Dict[str, Any]] = None,
    report_markdown: str = "",
    report_sections_json: Optional[Dict[str, Any]] = None,
    ai_source_badge: str = "GEMINI_AI",
    diff_summary_json: Optional[Dict[str, Any]] = None,
    reprocess_summary: str = ""
) -> Dict[str, Any]:
    conn = get_db_connection()
    now = datetime.now().isoformat()
    conn.execute("""
    INSERT INTO job_runs (
        id, job_id, workspace_id, version, trigger_type, gatekeeper_decision, gatekeeper_notes,
        plan_json, profiling_json, clean_data_path, clean_data_preview, report_markdown,
        report_sections_json, ai_source_badge, diff_summary_json, reprocess_summary, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        run_id, job_id, workspace_id, version, trigger_type, gatekeeper_decision, gatekeeper_notes,
        json.dumps(plan_json or {}, ensure_ascii=False),
        json.dumps(profiling_json or {}, ensure_ascii=False),
        clean_data_path,
        json.dumps(clean_data_preview or {}, ensure_ascii=False),
        report_markdown,
        json.dumps(report_sections_json or {}, ensure_ascii=False),
        ai_source_badge,
        json.dumps(diff_summary_json or {}, ensure_ascii=False),
        reprocess_summary,
        now
    ))
    conn.execute("UPDATE data_jobs SET current_run_version = ?, updated_at = ? WHERE id = ?", (version, now, job_id))
    conn.commit()
    return get_run(run_id)


def get_run(run_id: str) -> Optional[Dict[str, Any]]:
    conn = get_db_connection()
    row = conn.execute("SELECT * FROM job_runs WHERE id = ?", (run_id,)).fetchone()
    if not row:
        return None
    d = dict(row)
    for field in ["plan_json", "profiling_json", "clean_data_preview", "report_sections_json", "diff_summary_json"]:
        try:
            d[field] = json.loads(d.get(field) or "{}")
        except Exception:
            d[field] = {}
    return d


def get_latest_run(job_id: str) -> Optional[Dict[str, Any]]:
    conn = get_db_connection()
    row = conn.execute("SELECT * FROM job_runs WHERE job_id = ? ORDER BY version DESC LIMIT 1", (job_id,)).fetchone()
    if not row:
        return None
    d = dict(row)
    for field in ["plan_json", "profiling_json", "clean_data_preview", "report_sections_json", "diff_summary_json"]:
        try:
            d[field] = json.loads(d.get(field) or "{}")
        except Exception:
            d[field] = {}
    return d


def get_runs_by_job(job_id: str) -> List[Dict[str, Any]]:
    conn = get_db_connection()
    rows = conn.execute("SELECT * FROM job_runs WHERE job_id = ? ORDER BY version ASC", (job_id,)).fetchall()
    res = []
    for r in rows:
        d = dict(r)
        for field in ["plan_json", "profiling_json", "clean_data_preview", "report_sections_json", "diff_summary_json"]:
            try:
                d[field] = json.loads(d.get(field) or "{}")
            except Exception:
                d[field] = {}
        res.append(d)
    return res


# ========================================================
# CHANGE LOGS
# ========================================================

def add_change_logs(logs: List[Dict[str, Any]]):
    if not logs:
        return
    conn = get_db_connection()
    now = datetime.now().isoformat()
    records = []
    for log in logs:
        records.append((
            log.get("id") or f"cl-{os.urandom(6).hex()}",
            log["run_id"],
            log["job_id"],
            log.get("workspace_id", "ws-default"),
            log.get("file_name", ""),
            log.get("sheet_name", ""),
            log.get("row_index", 0),
            log.get("col_name", ""),
            str(log.get("old_value", "")),
            str(log.get("new_value", "")),
            log.get("change_type", "FORMAT_CLEAN"),
            log.get("reason", ""),
            log.get("source", "RULE"),
            now
        ))
    conn.executemany("""
    INSERT INTO change_logs (
        id, run_id, job_id, workspace_id, file_name, sheet_name, row_index,
        col_name, old_value, new_value, change_type, reason, source, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, records)
    conn.commit()


def get_change_logs(run_id: str, limit: int = 500) -> List[Dict[str, Any]]:
    conn = get_db_connection()
    rows = conn.execute(
        "SELECT * FROM change_logs WHERE run_id = ? ORDER BY row_index ASC LIMIT ?",
        (run_id, limit)
    ).fetchall()
    return [dict(r) for r in rows]


# ========================================================
# FINDINGS
# ========================================================

def add_findings(findings: List[Dict[str, Any]]):
    if not findings:
        return
    conn = get_db_connection()
    now = datetime.now().isoformat()
    records = []
    for f in findings:
        records.append((
            f.get("id") or f"find-{os.urandom(6).hex()}",
            f["run_id"],
            f["job_id"],
            f.get("workspace_id", "ws-default"),
            f["title"],
            f.get("severity", "MEDIUM"),
            f.get("category", "ANOMALY"),
            f.get("description", ""),
            json.dumps(f.get("evidence_refs", []), ensure_ascii=False),
            f.get("impact_estimate", ""),
            f.get("recommendation", ""),
            f.get("source", "RULE"),
            now
        ))
    conn.executemany("""
    INSERT INTO findings (
        id, run_id, job_id, workspace_id, title, severity, category, description,
        evidence_refs, impact_estimate, recommendation, source, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, records)
    conn.commit()


def get_findings(run_id: str) -> List[Dict[str, Any]]:
    conn = get_db_connection()
    rows = conn.execute("SELECT * FROM findings WHERE run_id = ? ORDER BY created_at ASC", (run_id,)).fetchall()
    res = []
    for r in rows:
        d = dict(r)
        d["evidence_refs"] = json.loads(d.get("evidence_refs") or "[]")
        res.append(d)
    return res


# ========================================================
# FEEDBACKS
# ========================================================

def add_feedback(feedback_data: Dict[str, Any]) -> str:
    conn = get_db_connection()
    fb_id = feedback_data.get("id") or f"fb-{os.urandom(6).hex()}"
    now = datetime.now().isoformat()
    conn.execute("""
    INSERT INTO feedbacks (
        id, job_id, run_id, workspace_id, user_id, level, target_ref,
        error_category, user_comment, expected_value, attachment_path,
        priority, status, agent_resolution_notes, conflict_evidence, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        fb_id,
        feedback_data["job_id"],
        feedback_data["run_id"],
        feedback_data.get("workspace_id", "ws-default"),
        feedback_data.get("user_id", "staff"),
        feedback_data.get("level", "REPORT"),
        feedback_data.get("target_ref", ""),
        feedback_data["error_category"],
        feedback_data["user_comment"],
        feedback_data.get("expected_value", ""),
        feedback_data.get("attachment_path", ""),
        feedback_data.get("priority", "MEDIUM"),
        feedback_data.get("status", "PENDING"),
        feedback_data.get("agent_resolution_notes", ""),
        json.dumps(feedback_data.get("conflict_evidence", {}), ensure_ascii=False),
        now
    ))
    conn.commit()
    return fb_id


def get_feedbacks(job_id: str, run_id: Optional[str] = None) -> List[Dict[str, Any]]:
    conn = get_db_connection()
    if run_id:
        rows = conn.execute("SELECT * FROM feedbacks WHERE run_id = ? ORDER BY created_at ASC", (run_id,)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM feedbacks WHERE job_id = ? ORDER BY created_at ASC", (job_id,)).fetchall()
    res = []
    for r in rows:
        d = dict(r)
        try:
            d["conflict_evidence"] = json.loads(d.get("conflict_evidence") or "{}")
        except Exception:
            d["conflict_evidence"] = {}
        res.append(d)
    return res


def update_feedback_status(feedback_id: str, status: str, resolution_notes: str = "", conflict_evidence: Optional[Dict[str, Any]] = None):
    conn = get_db_connection()
    c_json = json.dumps(conflict_evidence or {}, ensure_ascii=False)
    conn.execute(
        "UPDATE feedbacks SET status = ?, agent_resolution_notes = ?, conflict_evidence = ? WHERE id = ?",
        (status, resolution_notes, c_json, feedback_id)
    )
    conn.commit()


# ========================================================
# LESSONS LEARNED
# ========================================================

def add_lesson(
    workspace_id: str,
    category: str,
    rule_key: str,
    rule_content: str,
    source_job_id: Optional[str] = None,
    source_feedback_id: Optional[str] = None,
    created_by: str = "staff"
) -> str:
    conn = get_db_connection()
    les_id = f"les-{os.urandom(6).hex()}"
    now = datetime.now().isoformat()
    conn.execute("""
    INSERT INTO lessons (
        id, workspace_id, source_job_id, source_feedback_id, category,
        rule_key, rule_content, is_active, created_by, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?)
    """, (
        les_id, workspace_id, source_job_id, source_feedback_id, category,
        rule_key, rule_content, created_by, now
    ))
    conn.commit()
    return les_id


def get_active_lessons(workspace_id: str) -> List[Dict[str, Any]]:
    conn = get_db_connection()
    rows = conn.execute(
        "SELECT * FROM lessons WHERE workspace_id = ? AND is_active = 1 ORDER BY created_at DESC",
        (workspace_id,)
    ).fetchall()
    return [dict(r) for r in rows]


def list_lessons(workspace_id: str) -> List[Dict[str, Any]]:
    conn = get_db_connection()
    rows = conn.execute(
        "SELECT * FROM lessons WHERE workspace_id = ? ORDER BY created_at DESC",
        (workspace_id,)
    ).fetchall()
    return [dict(r) for r in rows]


def delete_lesson(lesson_id: str) -> bool:
    conn = get_db_connection()
    conn.execute("DELETE FROM lessons WHERE id = ?", (lesson_id,))
    conn.commit()
    return True


def toggle_lesson(lesson_id: str, is_active: bool) -> bool:
    conn = get_db_connection()
    conn.execute("UPDATE lessons SET is_active = ? WHERE id = ?", (1 if is_active else 0, lesson_id))
    conn.commit()
    return True


# ========================================================
# EVALUATIONS
# ========================================================

def save_evaluation(eval_data: Dict[str, Any]) -> str:
    conn = get_db_connection()
    eval_id = eval_data.get("id") or f"eval-{os.urandom(6).hex()}"
    now = datetime.now().isoformat()
    conn.execute("""
    INSERT INTO evaluations (
        id, job_id, run_id, workspace_id, user_id, rating_stars,
        findings_decisions, confidence_score, general_notes, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        eval_id,
        eval_data["job_id"],
        eval_data["run_id"],
        eval_data.get("workspace_id", "ws-default"),
        eval_data.get("user_id", "staff"),
        eval_data.get("rating_stars", 5),
        json.dumps(eval_data.get("findings_decisions", {}), ensure_ascii=False),
        eval_data.get("confidence_score", 90),
        eval_data.get("general_notes", ""),
        now
    ))
    conn.commit()
    return eval_id


def get_evaluation(job_id: str) -> Optional[Dict[str, Any]]:
    conn = get_db_connection()
    row = conn.execute("SELECT * FROM evaluations WHERE job_id = ? ORDER BY created_at DESC LIMIT 1", (job_id,)).fetchone()
    if not row:
        return None
    d = dict(row)
    d["findings_decisions"] = json.loads(d.get("findings_decisions") or "{}")
    return d


# ========================================================
# ERROR REPORTS (BRANCH B4)
# ========================================================

def add_error_reports(reports: List[Dict[str, Any]]):
    if not reports:
        return
    conn = get_db_connection()
    now = datetime.now().isoformat()
    records = []
    for r in reports:
        records.append((
            r.get("id") or f"err-{os.urandom(6).hex()}",
            r.get("job_id", ""),
            r.get("workspace_id", "ws-default"),
            r.get("error_code", "ERR_DATA_INVALID"),
            r.get("severity", "BLOCKER"),
            r.get("file_name", ""),
            r.get("sheet_name", ""),
            r.get("row_index", 0),
            r.get("col_name", ""),
            str(r.get("offending_value", "")),
            r.get("cause", ""),
            r.get("suggested_fix", ""),
            r.get("ai_explanation", ""),
            now
        ))
    conn.executemany("""
    INSERT INTO error_reports (
        id, job_id, workspace_id, error_code, severity, file_name, sheet_name,
        row_index, col_name, offending_value, cause, suggested_fix, ai_explanation, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, records)
    conn.commit()


def get_error_reports(job_id: str) -> List[Dict[str, Any]]:
    conn = get_db_connection()
    rows = conn.execute("SELECT * FROM error_reports WHERE job_id = ? ORDER BY severity DESC, row_index ASC", (job_id,)).fetchall()
    return [dict(r) for r in rows]


# ========================================================
# QUALITY ANALYTICS & DASHBOARD METRICS
# ========================================================

def get_dashboard_metrics(workspace_id: str = "ws-default") -> Dict[str, Any]:
    conn = get_db_connection()
    
    # 1. Total jobs by status
    status_rows = conn.execute("""
    SELECT status, COUNT(*) as cnt FROM data_jobs WHERE workspace_id = ? GROUP BY status
    """, (workspace_id,)).fetchall()
    status_counts = {r["status"]: r["cnt"] for r in status_rows}
    total_jobs = sum(status_counts.values())

    # 2. Error rate (jobs failed / total jobs)
    failed_count = status_counts.get("FAILED", 0)
    error_rate = round((failed_count / total_jobs * 100), 1) if total_jobs > 0 else 0.0

    # 3. Average evaluation rating
    eval_row = conn.execute("""
    SELECT AVG(rating_stars) as avg_rating, COUNT(*) as total_evals FROM evaluations WHERE workspace_id = ?
    """, (workspace_id,)).fetchone()
    avg_rating = round(eval_row["avg_rating"], 1) if eval_row and eval_row["avg_rating"] else 4.8

    # 4. Average feedback rounds (version count per job)
    version_row = conn.execute("""
    SELECT AVG(current_run_version) as avg_versions FROM data_jobs WHERE workspace_id = ?
    """, (workspace_id,)).fetchone()
    avg_rounds = round(version_row["avg_versions"], 1) if version_row and version_row["avg_versions"] else 1.2

    # 5. Common error categories
    fb_rows = conn.execute("""
    SELECT error_category, COUNT(*) as cnt FROM feedbacks WHERE workspace_id = ? GROUP BY error_category ORDER BY cnt DESC LIMIT 5
    """, (workspace_id,)).fetchall()
    common_errors = [{r["error_category"]: r["cnt"]} for r in fb_rows]

    return {
        "total_jobs": total_jobs,
        "status_counts": status_counts,
        "error_rate_percent": error_rate,
        "avg_user_rating": avg_rating,
        "avg_feedback_rounds": avg_rounds,
        "common_error_categories": [dict(r) for r in fb_rows]
    }


# Safe auto-init DB upon import
try:
    init_db()
except Exception as _e:
    print(f"Warning: init_db failed on import: {_e}")
